﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HexMapEditor : Photon.PunBehaviour {

    public int activeTerrainTypeIndex = -1;

    public HexGrid hexGrid;

    private List<HexCellData> ListedCells;

    
    public int activeElevation;
    public int activeWaterLevel;
    int brushSize;
    public int activeUrbanLevel, activeFarmLevel, activePlantLevel, activeSpecialIndex;

    bool applyElevation = true;
    bool applyWaterLevel = true;
    bool applyUrbanLevel, applyFarmLevel, applyPlantLevel, applySpecialIndex;

    //variable used to check whether an auto save is in process
    bool autoSaveRunning = false;

    

    public enum OptionalToggle
    {
        Ignore, Yes, No
    }

    public Toggle wallOn, wallOff, riverOn, riverOff, roadOn, roadOff;
    public Text ToolLabel;

    public OptionalToggle riverMode, roadMode, walledMode;
    bool isDrag;
    HexDirection dragDirection;
    HexCell previousCell;

    void Awake()
    {
       
    }

    // Use this for initialization
    void Start () {
		
        ListedCells = new List<HexCellData>();
        ListedCells.Clear();
}

    // Update is called once per frame
    void Update()
    {


        if (Input.GetMouseButton(0) && !EventSystem.current.IsPointerOverGameObject())
        {
            HandleInput();
        }


        else {
            previousCell = null;
        }


        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyUp(KeyCode.Z))
        {
            if (ListedCells.Count > 0)
            {
                Debug.Log("size of list " + ListedCells.Count);
                Undo(ListedCells.ElementAt(ListedCells.Count - 1), hexGrid.GetCell(ListedCells.ElementAt(ListedCells.Count - 1).coordinates));
                ListedCells.RemoveAt(ListedCells.Count - 1);
            }
        }

    }


    void HandleInput()
    {
        Ray inputRay = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(inputRay, out hit))
        {
            HexCell currentCell = hexGrid.GetCell(hit.point);
            if (previousCell && previousCell != currentCell)
            {
                ValidateDrag(currentCell);
            }
            else
            {
                isDrag = false;
            }

            
                EditCells(currentCell);
            
            previousCell = currentCell;

            
        }

        else {
            previousCell = null;
        }
    }

    void ValidateDrag(HexCell currentCell)
    {
        for (
            dragDirection = HexDirection.NE;
            dragDirection <= HexDirection.NW;
            dragDirection++
        )
        {
            if (previousCell.GetNeighbor(dragDirection) == currentCell)
            {
                isDrag = true;
                return;
            }
        }
        isDrag = false;
    }



    void EditCells(HexCell center)
    {
        int centerX = center.coordinates.X;
        int centerZ = center.coordinates.Z;

        for (int r = 0, z = centerZ - brushSize; z <= centerZ; z++, r++)
        {
            for (int x = centerX - r; x <= centerX + brushSize; x++)
            {
                EditCell(hexGrid.GetCell(new HexCoordinates(x, z)));
            }
        }

        for (int r = 0, z = centerZ + brushSize; z > centerZ; z--, r++)
        {
            for (int x = centerX - brushSize; x <= centerX + r; x++)
            {
                EditCell(hexGrid.GetCell(new HexCoordinates(x, z)));
            }
        }
    }

    void Undo(HexCellData old, HexCell real)
    {
        Debug.Log("undo to: " + old.terrainTypeIndex);
        PhotonView photonView = PhotonView.Get(real.chunk.GetComponent<PhotonView>());
        if (old.terrainTypeIndex != null)
        {
            real.TerrainTypeIndex = (int)old.terrainTypeIndex;
            photonView.RPC("sendTerrain", PhotonTargets.Others, real.cellIndex, (int)old.terrainTypeIndex);
        }

        if (old.elevation != null)
        {
            real.Elevation = (int)old.elevation;
            photonView.RPC("sendElevation", PhotonTargets.Others, real.cellIndex, (int)old.elevation);

        }

        if (old.waterLevel != null)
        {
            real.WaterLevel = (int)old.waterLevel;
            photonView.RPC("sendWaterLevel", PhotonTargets.Others, real.cellIndex, (int)old.waterLevel);
        }

        if (old.specialIndex != null)
        {
            real.SpecialIndex = (int)old.specialIndex;
            photonView.RPC("sendSpecialIndex", PhotonTargets.Others, real.cellIndex, (int)old.specialIndex);
        }

        if (old.urbanLevel != null)
        {
            real.UrbanLevel = (int)old.urbanLevel;
            photonView.RPC("sendUrbanLevel", PhotonTargets.Others, real.cellIndex, (int)old.urbanLevel);
        }


        if (old.farmLevel != null)
        {
            real.FarmLevel = (int)old.farmLevel;
            photonView.RPC("sendFarmLevel", PhotonTargets.Others, real.cellIndex, (int)old.farmLevel);
        }

        if (old.plantLevel != null)
        {
            real.PlantLevel = (int)old.plantLevel;
            photonView.RPC("sendPlantLevel", PhotonTargets.Others, real.cellIndex, (int)old.plantLevel);
        }

        if (old.walled != null)
        {
            if (old.walled == true)
            {
                real.Walled = false;

            }

            else
            {
                real.Walled = true;
            }
        
            
        }

        if (old.riverState != null)
        {

            if (old.riverState == "RemoveRiver")
            {
                real.RemoveRiver();
            }

            else if(old.riverState == "AddRiver")
            {



                real.GetNeighbor(old.incomingRiver).SetOutgoingRiver(old.incomingRiver.Opposite());

                if (old.hasOutgoingRiver == true)
                {
                    real.SetOutgoingRiver(old.outgoingRiver);
                }
            }

        }

        if (old.roadState != null)
        {
            if (old.roadState == "RemoveRoad")
            {
                real.RemoveRoads();

                
                
            }

            else if (old.roadState == "AddRoad")
            {
                //real.AddRoad(old.dragDirection);
                //real.GetNeighbor(old.dragDirection.Opposite()).AddRoad(old.dragDirection);
                for (int i = 0; i < old.roads.Length; i++)
                {
                    if (old.roads[i] == true)
                    {
                        real.SetRoad(i, true);
                    }
                }


            }
        }


        real.Refresh();
      
    }

    void EditCell(HexCell cell)
    {
        bool[] checks = new bool[10] {false, false, false, false, false, false, false, false, false, false};
        HexCellData old = new HexCellData();
        old.cellIndex = cell.cellIndex;
        old.chunk = cell.chunk;
        old.coordinates = cell.coordinates;


       



        if (cell)
        {

            PhotonView photonView = PhotonView.Get(cell.chunk.GetComponent<PhotonView>());

            if (activeTerrainTypeIndex >= 0 && cell.TerrainTypeIndex != activeTerrainTypeIndex)
            {
                checks[0] = true;
                old.terrainTypeIndex = cell.terrainTypeIndex;
                cell.TerrainTypeIndex = activeTerrainTypeIndex;
                photonView.RPC("sendTerrain", PhotonTargets.Others, cell.cellIndex, activeTerrainTypeIndex);
            }
            if (applyElevation && cell.Elevation != activeElevation)
            {
                checks[1] = true;
                old.elevation = cell.Elevation;
                cell.Elevation = activeElevation;
                photonView.RPC("sendElevation", PhotonTargets.Others, cell.cellIndex, activeElevation);
            }
            if (applyWaterLevel && cell.WaterLevel != activeWaterLevel)
            {
                checks[2] = true;
                old.waterLevel = cell.WaterLevel;
                cell.WaterLevel = activeWaterLevel;
                photonView.RPC("sendWaterLevel", PhotonTargets.Others, cell.cellIndex, activeWaterLevel);
            }
            if (applySpecialIndex && cell.SpecialIndex != activeSpecialIndex)
            {
                checks[3] = true;
                old.specialIndex = cell.SpecialIndex;
                cell.SpecialIndex = activeSpecialIndex;
                photonView.RPC("sendSpecialIndex", PhotonTargets.Others, cell.cellIndex, activeSpecialIndex);
            }
            if (applyUrbanLevel && cell.UrbanLevel != activeUrbanLevel)
            {
                checks[4] = true;
                old.urbanLevel = cell.UrbanLevel;
                cell.UrbanLevel = activeUrbanLevel;
                photonView.RPC("sendUrbanLevel", PhotonTargets.Others, cell.cellIndex, activeUrbanLevel);
            }
            if (applyFarmLevel && cell.FarmLevel != activeFarmLevel)
            {
                checks[5] = true;
                old.farmLevel = cell.FarmLevel;
                cell.FarmLevel = activeFarmLevel;
                photonView.RPC("sendFarmLevel", PhotonTargets.Others, cell.cellIndex, activeFarmLevel);
            }
            if (applyPlantLevel && cell.PlantLevel != activePlantLevel)
            {
                checks[6] = true;
                old.plantLevel = cell.PlantLevel;
                cell.PlantLevel = activePlantLevel;
                photonView.RPC("sendPlantLevel", PhotonTargets.Others, cell.cellIndex, activePlantLevel);
            }
            if (riverMode == OptionalToggle.No)
            {
                if (cell.HasRiver)
                {
                    checks[7] = true;
                    old.riverState = "AddRiver";
                    old.hasOutgoingRiver = cell.hasOutgoingRiver;
                    Debug.Log("cell has outgoing river: " + cell.hasOutgoingRiver);
                    old.outgoingRiver = cell.outgoingRiver;
                    old.hasIncomingRiver = cell.hasIncomingRiver;
                    old.incomingRiver = cell.incomingRiver;

                }
                cell.RemoveRiver();
                photonView.RPC("removeRiver", PhotonTargets.Others, cell.cellIndex);
            }
            if (roadMode == OptionalToggle.No)
            {
                if (cell.HasRoads)
                {
                    checks[8] = true;
                    old.roadState = "AddRoad";
                    for (int i = 0; i < cell.roads.Length; i++)
                    {
                        old.roads[i] = cell.roads[i];
                    }
                
                }
              
                cell.RemoveRoads();
                photonView.RPC("removeRoads", PhotonTargets.Others, cell.cellIndex);
            }
            if (walledMode != OptionalToggle.Ignore)
            {
                checks[9] = true;
                old.walled = walledMode == OptionalToggle.Yes;
                cell.Walled = walledMode == OptionalToggle.Yes;
                photonView.RPC("sendWalls", PhotonTargets.Others, cell.cellIndex, cell.Walled);
            }
            if (isDrag)
            {
                HexCell otherCell = cell.GetNeighbor(dragDirection.Opposite());
                HexCellData otherOld = new HexCellData();
                otherOld.cellIndex = otherCell.cellIndex;
                otherOld.chunk = otherCell.chunk;
                otherOld.coordinates = otherCell.coordinates;

                if (otherCell)
                {
                    if (riverMode == OptionalToggle.Yes)
                    {
                        otherOld.riverState = "RemoveRiver"; 
                        otherOld.hasOutgoingRiver = otherCell.hasOutgoingRiver;
                        otherOld.hasIncomingRiver = otherCell.hasIncomingRiver;
                        otherCell.SetOutgoingRiver(dragDirection);
                        ListedCells.Add(otherOld);
                        photonView.RPC("setOutgoingRiver", PhotonTargets.Others,cell.cellIndex, (int)(dragDirection));
                    }
                    if (roadMode == OptionalToggle.Yes)
                    {

                        otherOld.roadState = "RemoveRoad";
                        otherOld.roads = cell.roads;
                        otherOld.dragDirection = dragDirection;
                        otherCell.AddRoad(dragDirection);
                        ListedCells.Add(otherOld);
                        photonView.RPC("addRoad", PhotonTargets.Others, cell.cellIndex, (int)(dragDirection));
                    }


                        
                    
                    
                }       
                
                     
            }

            for (int i = 0; i < checks.Length; i++)
            {
                if (checks[i] == true)
                {
                    ListedCells.Add(old);
                    break;
                }
            }

            if (ListedCells.Count > 100)
            {
                ListedCells.RemoveAt(0);
            }

            //temporarily disabled autosave feature

            /*
            if (autoSaveRunning == false)
            {
                StartCoroutine(autoSave());
            }
            */
        }


    }

    public void SetTerrainTypeIndex(int index)
    {
        activeTerrainTypeIndex = index;
    }

    public void SetElevation(float elevation)
    {
        activeElevation = (int)elevation;
        ToolLabel.text = activeElevation.ToString() ;
        Debug.Log(ToolLabel.text);
       
    }

    public void SetApplyElevation(bool toggle)
    {
        applyElevation = toggle;
    }

    public void SetBrushSize(float size)
    {
        brushSize = (int)size;

    }

    public void SetRiverMode(int mode)
    {
        riverMode = (OptionalToggle)mode;

        if (mode == 1)
        {

            ColorBlock cb1 = riverOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 25);
            riverOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = riverOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 255);
            riverOff.GetComponent<Toggle>().colors = cb2;
        }

        else if (mode == 2)
        {
            ColorBlock cb1 = riverOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 255);
            riverOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = riverOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 25);
            riverOff.GetComponent<Toggle>().colors = cb2;
        }
    }

    public void SetRoadMode(int mode)
    {
        roadMode = (OptionalToggle)mode;

        if (mode == 1)
        {

            ColorBlock cb1 = roadOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 25);
            roadOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = roadOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 255);
            roadOff.GetComponent<Toggle>().colors = cb2;
        }

        else if (mode == 2)
        {
            ColorBlock cb1 = roadOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 255);
            roadOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = roadOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 25);
            roadOff.GetComponent<Toggle>().colors = cb2;
        }
    }

    public void SetWalledMode(int mode)
    {
        walledMode = (OptionalToggle)mode;
        Color selected = new Color(103f, 103f, 103f, 255f);

        if (mode == 1)
        {

            ColorBlock cb1 = wallOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 25);
            wallOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = wallOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 255);
            wallOff.GetComponent<Toggle>().colors = cb2;
        }

        else if (mode == 2)
        {
            ColorBlock cb1 = wallOn.GetComponent<Toggle>().colors;
            cb1.normalColor = new Color32(255, 255, 255, 255);
            wallOn.GetComponent<Toggle>().colors = cb1;
            ColorBlock cb2 = wallOff.GetComponent<Toggle>().colors;
            cb2.normalColor = new Color32(255, 255, 255, 25);
            wallOff.GetComponent<Toggle>().colors = cb2;
        }
        
    }

    public void SetApplyWaterLevel(bool toggle)
    {
        applyWaterLevel = toggle;
    }

    public void SetWaterLevel(float level)
    {
        activeWaterLevel = (int)level;
    }

    public void SetApplyUrbanLevel(bool toggle)
    {
        applyUrbanLevel = toggle;
    }

    public void SetUrbanLevel(float level)
    {
        activeUrbanLevel = (int)level;
    }


    public void SetApplyFarmLevel(bool toggle)
    {
        applyFarmLevel = toggle;
    }

    public void SetFarmLevel(float level)
    {
        activeFarmLevel = (int)level;
    }

    public void SetApplyPlantLevel(bool toggle)
    {
        applyPlantLevel = toggle;
    }

    public void SetPlantLevel(float level)
    {
        activePlantLevel = (int)level;
    }

    public void SetApplySpecialIndex(bool toggle)
    {
        applySpecialIndex = toggle;
    }

    public void SetSpecialIndex(int index)
    {
        activeSpecialIndex = index;
    }

    public void ShowUI(bool visible)
    {
        hexGrid.ShowUI(visible);
    }

    IEnumerator autoSave()
    {
        //Do things before
        autoSaveRunning = true;

        //Wait 60 seconds
        yield return new WaitForSecondsRealtime(60);

        if (PhotonNetwork.isMasterClient)
        {

            string path = Path.Combine(Application.dataPath + "/../SaveData/", "Temp.map");
            using (
                BinaryWriter writer =
                    new BinaryWriter(File.Open(path, FileMode.Create))
            )
            {
                writer.Write(1);
                hexGrid.Save(writer);
            }
        }

        //Do things after 
        autoSaveRunning = false;

    }

    public byte[] ToMemory()
    {
        List<byte> bytes = new List<byte>();
        MemoryStream stream = new MemoryStream();

        using (
            BinaryWriter writer =
                new BinaryWriter(stream))
        {
            writer.Write(1);
            hexGrid.Save(writer);

            return stream.ToArray();

        }
  

    }


    public override void OnPhotonPlayerConnected(PhotonPlayer newPlayer)
    {
        Debug.Log("Player Connected");
        if (PhotonNetwork.isMasterClient)
        {
            byte[] mapData = ToMemory();
            //byte[] mapData = FileToByteArray();
            Debug.Log("I am Master");

           
            PhotonView photonview = PhotonView.Get(hexGrid.GetComponent<PhotonView>());

            photonview.RPC("Load", PhotonTargets.Others, mapData);
        }
    }
    
   



}
