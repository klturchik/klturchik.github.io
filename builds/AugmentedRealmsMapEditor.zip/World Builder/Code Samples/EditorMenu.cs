﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EditorMenu : MonoBehaviour {

    public GameObject HexMapEditorInstance;
    public GameObject ColorPanel;
    public GameObject WallPanel;
    public GameObject RiverPanel;
    public GameObject RoadPanel;
    public GameObject ElevationPanel;
    public GameObject WaterPanel;
    public GameObject SmallFeaturesPanel;
    public GameObject LargeFeaturesPanel;

    public Text ToolLabel;
    public Text ToolField;
    public Slider ToolSlider;
    public Slider Urban;
    public Slider Farms;
    public Slider Forest;
    private HexMapEditor editor;

    private int savedColor;
    private int savedWallMode;
    private int savedRiverMode;
    private int savedRoadMode;
    private int savedHeight;

    


    public void Start()
    {
        editor = HexMapEditorInstance.GetComponent<HexMapEditor>();
    }


    public void ToggleColorPanel()
    {
        if (ColorPanel.activeSelf == true)
        {
            ColorPanel.SetActive(false);
            savedColor = (int)editor.activeTerrainTypeIndex;
            editor.SetTerrainTypeIndex(-1);
        }
        else
        {
            ColorPanel.SetActive(true);
            editor.SetTerrainTypeIndex(savedColor);

            
        }

    }


    public void ToggleWallPanel()
    {
        if (WallPanel.activeSelf == true)
        {
            WallPanel.SetActive(false);

            savedWallMode = (int)editor.walledMode;
            editor.SetWalledMode(0);
        }
        else
        {
            WallPanel.SetActive(true);
            editor.SetWalledMode(savedWallMode);

        }
    }


    public void ToggleRiverPanel()
    {
        if (RiverPanel.activeSelf == true)
        {
            RiverPanel.SetActive(false);

            savedRiverMode = (int)editor.riverMode;
            editor.SetRiverMode(0);
        }
        else
        {
            RiverPanel.SetActive(true);
            editor.SetRiverMode(savedRiverMode);

            if (RoadPanel.activeSelf == true)
            {
                ToggleRoadPanel();
            }
        }
    }


    public void ToggleRoadPanel()
    {
        if (RoadPanel.activeSelf == true)
        {
            RoadPanel.SetActive(false);

            savedRoadMode = (int)editor.roadMode;
            editor.SetRoadMode(0);
        }
        else
        {
            RoadPanel.SetActive(true);
            editor.SetRoadMode(savedRoadMode);

            if (RiverPanel.activeSelf == true)
            {
                ToggleRiverPanel();
            }
        }
    }

    public void ToggleElevationPanel()
    {
        if (ElevationPanel.activeSelf == true && ToolLabel.text == "Elevation Level")
        {
            ElevationPanel.SetActive(false);
            editor.SetApplyElevation(false);

           
        }
        else
        {
            ElevationPanel.SetActive(true);
            editor.SetApplyElevation(true);
            editor.SetApplyWaterLevel(false);

            ToolLabel.text = "Elevation Level";
            ToolSlider.minValue = 0;
            ToolSlider.maxValue = 10;
        }
    }


    public void ToggleWaterPanel()
    {
        if (WaterPanel.activeSelf == true && ToolLabel.text == "Water Level")
        {
            WaterPanel.SetActive(false);
            editor.SetApplyWaterLevel(false);
        }
        else
        {
            WaterPanel.SetActive(true);
            editor.SetApplyWaterLevel(true);
            editor.SetApplyElevation(false);

            ToolLabel.text = "Water Level";
            ToolSlider.minValue = 0;
            ToolSlider.maxValue = 10;
        }
    }


    public void ToggleSmallFeaturesPanel()
    {
        if (SmallFeaturesPanel.activeSelf == true)
        {
            SmallFeaturesPanel.SetActive(false);
            editor.SetApplyUrbanLevel(false);
            editor.SetApplyFarmLevel(false);
            editor.SetApplyPlantLevel(false);
        }
        else
        {
            SmallFeaturesPanel.SetActive(true);
            editor.SetApplyUrbanLevel(true);
            editor.SetApplyFarmLevel(true);
            editor.SetApplyPlantLevel(true);
        }
    }



    public void ToggleLargeFeaturePanel()
    {
        if (LargeFeaturesPanel.activeSelf == true)
        {
            LargeFeaturesPanel.SetActive(false);
            editor.SetApplySpecialIndex(false);
        }
        else
        {
            LargeFeaturesPanel.SetActive(true);
            editor.SetApplySpecialIndex(true);
        }
    }


	
}
