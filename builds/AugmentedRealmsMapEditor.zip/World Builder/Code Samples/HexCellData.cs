﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HexCellData  {

    public int cellIndex;
    public HexGridChunk chunk;
    public HexCoordinates coordinates;
    public int? terrainTypeIndex = null;
    public int? elevation = null;
    public int? waterLevel = null;
    public int? specialIndex = null;
    public int? urbanLevel = null;
    public int? farmLevel = null;
    public int? plantLevel = null;
    public bool? walled = null;
    public bool? hasRiver = null;
    public bool? hasIncomingRiver = null;
    public bool? hasOutgoingRiver = null;
    public HexDirection incomingRiver;
    public HexDirection outgoingRiver;
    public HexDirection dragDirection;
    public bool? hasRoads = null;
    public bool[] roads = {false, false, false, false, false, false };
    public string riverState = null;
    public string roadState = null;


}
